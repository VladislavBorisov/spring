package com.vlado.spring.test;

public class Person {
	public void speak() {
		System.out.println("Hello! I'm a new in spring.");
	}
}
